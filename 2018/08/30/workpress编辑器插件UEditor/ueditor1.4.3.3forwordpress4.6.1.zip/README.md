#插件名：UEditor-KityFormula for wordpress

基于ueditor for wordpress

添加了百度数学公式插件kityformula,使之进一步完善。

# 提醒
此版本为免费wordpress插件，纯免费使用不存在任何费用，任何人不得以付费形式提供给其他人。

# 自定义配置
+ 工具栏图标3行显示、并重新整理排序；
+ 工具栏顶部间距32px；
+ 编辑器字体大小14px、行高1.8；
+ 设置编辑器默认320px高，可拖动改变高度；
+ 关闭字数显示；
+ 关闭抓取远程图片；

Ueditor1.4.3.3 + KityFormula数学公式编器for wordpress


## 更新记录：

### 版本： 2.0.1        2016-11-6发布

### 版本： 2.0.2	   2017-02-23发布
自从UEditor-KityFormula-for-wordpress 2.0.1版本发布以来，用户反应较好，对某些使用者提出的没有百度地图、google地图及iframe,2.0.2版本进行了补充。现已发布，不过谷歌地图由于某些原因，国内应用不了，需要使用vpn，建议使用百度地图。

说明：http://www.yangshengliang.com/kaiyuan-shijie/zuopin/678.html

### 安装方法
#### 一：git方式

1. 切换到wordpress网站根目录
2. git clone http://git.oschina.net/fedkey/UEditor-KityFormula-for-wordpress wp-content/plugins/UEditor-KityFormula-for-wordpress
3. 到网站后台启用 [UEditor-KityFormula-for-wordpress] 插件

#### 二：zip方式
1、 访问： http://git.oschina.net/fedkey/UEditor-KityFormula-for-wordpress 左上角找到 zip下载按钮,如下图所示：

![zip压缩包下载指南](http://git.oschina.net/uploads/images/2017/0223/105152_be575a94_322734.png "在这里输入图片标题")


2、 登陆wordpress后台，用上传插件的方式进行安装，并启用。
